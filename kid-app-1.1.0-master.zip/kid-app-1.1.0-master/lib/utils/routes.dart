class AllRoutes {
  static String loginRoute = "/login";
  static String homeRoute = "/home";
  static String animalRoute = "/animals";
  static String birdsRoute = "/birds";
  static String shapesRoute = "/shapes";
  static String solarRoute = "/solar";
  static String atozRoute = "/atoz";
  static String aboutRoute = "/about";
  static String flipgameRout = "/flipcard";
}
