package vdrs.sappu.lafk.learn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
